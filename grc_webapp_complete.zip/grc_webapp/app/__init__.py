"""Flask application factory."""
import sys
from flask import Flask, jsonify

import config
from app.services.inventory_service import InventoryService


def create_app(erg_path=None, model_path=None, db_path=None):
    app = Flask(__name__)

    # Make the original research modules importable (data_loader, feature_extraction, ...).
    # They are used exactly as written; this app never edits them.
    research = str(config.RESEARCH_DIR)
    if research not in sys.path:
        sys.path.insert(0, research)

    # The workbook is read ONCE at startup (about 5 s), not per request.
    inventory = InventoryService.from_workbook(erg_path or config.ERG_PATH)
    app.extensions["inventory"] = inventory

    # Phases 2-8: model, compliance, history. Built once at startup; a schema mismatch stops the app.
    from app.services.model_service import ModelService
    from app.services.compliance_service import ComplianceService
    from app.services.assessment_service import AssessmentService
    from app.services.store import Store
    model = ModelService(inventory.inv, erg_path or config.ERG_PATH, model_path or config.MODEL_PATH)
    compliance = ComplianceService(inventory.inv, model.labels_df)
    store = Store(db_path or config.DB_PATH)
    app.extensions.update(model=model, compliance=compliance, store=store,
                          assessments=AssessmentService(inventory, model, compliance, store))

    from app.routes.inventory import bp as inventory_bp
    from app.routes.pages import bp as pages_bp
    from app.routes.assess import bp as assess_bp
    app.register_blueprint(assess_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(pages_bp)

    @app.errorhandler(404)
    def _404(e):
        return jsonify({"error": "not_found", "message": "Resource not found."}), 404

    @app.errorhandler(405)
    def _405(e):
        return jsonify({"error": "method_not_allowed", "message": "Method not allowed."}), 405

    return app
