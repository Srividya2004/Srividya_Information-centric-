(function () {
  "use strict";
  var el = U.el, $ = function (id) { return document.getElementById(id); };
  function f4(x) { return (typeof x === "number") ? x.toFixed(4) : x; }

  U.jget("/api/assessments/" + window.AID).then(function (r) {
    if (!r.ok) { $("loading").textContent = "Could not load this assessment."; return; }
    render(r.data);
  });

  function render(a) {
    $("loading").hidden = true; $("app").hidden = false;
    $("assets").textContent = a.assets.map(function (x) { return x.asset_id + " " + x.asset_name + " (" + x.asset_type + ")"; }).join("  ·  ");
    var dl = $("downloads");
    [["PDF report", "/assessments/" + a.id + "/report.pdf"], ["Recommendations CSV", "/assessments/" + a.id + "/report.csv"]].forEach(function (x) {
      var l = el("a", x[0]); l.href = x[1]; dl.appendChild(l);
    });
    a.warnings.forEach(function (w) { $("warnings").appendChild(el("div", w, "warn")); });
    summary(a); shap(a); lime(a); compare(a); compliance(a); features(a);
    document.querySelectorAll(".tab").forEach(function (t) {
      t.addEventListener("click", function () {
        document.querySelectorAll(".tab").forEach(function (o) { o.setAttribute("aria-selected", o === t ? "true" : "false"); });
        document.querySelectorAll(".panel").forEach(function (p) { p.hidden = p.id !== "p-" + t.dataset.tab; });
        window.dispatchEvent(new Event("resize"));
      });
    });
  }

  function summary(a) {
    var p = a.prediction, box = $("p-summary");
    var h = el("h2", "Predicted class: "); var pill = el("span", p.label, "pill " + p.label); h.appendChild(pill); box.appendChild(h);
    var cols = el("div", null, "cols"), left = el("div"), right = el("div");
    var cv = el("div", null, "chartbox"), c = el("canvas"); cv.appendChild(c); left.appendChild(cv);
    var order = ["Low", "Medium", "High"];
    U.barChart(c, order, order.map(function (k) { return p.probabilities[k] * 100; }),
      { fmt: function (v) { return v.toFixed(1) + "%"; }, yTitle: "Probability (%)", colorFn: function () { return "#1f5fbf"; } });
    var dl = el("dl", null, "kv");
    function kv(k, v) { dl.appendChild(el("dt", k)); dl.appendChild(el("dd", v)); }
    order.forEach(function (k) { kv("P(" + k + ")", (p.probabilities[k] * 100).toFixed(2) + "%"); });
    kv("Model input", p.model_input_shape[0] + " row × " + p.model_input_shape[1] + " columns");
    var d = p.dataset_record;
    kv("In the 14,000 combinations?", d.seen_in_training_set ? "Yes (" + d.combination_id + ", " + d.split + " split)" : "No – a new combination");
    if (d.seen_in_training_set) kv("Stored dataset label", d.stored_label + " (rule-based)");
    var mc = a.model_checks; kv("Model checks at startup", Object.keys(mc).every(function (k) { return mc[k].ok; }) ? "all passed" : "FAILED");
    right.appendChild(dl);
    right.appendChild(el("p", "The class shown is CatBoost's own top class. The dataset label (when the combination is in the data) is a separate, rule-based value.", "muted small"));
    cols.appendChild(left); cols.appendChild(right); box.appendChild(cols);
    box.appendChild(el("h3", "Selected assets"));
    box.appendChild(U.table([{ label: "ID", key: "asset_id" }, { label: "Name", key: "asset_name" }, { label: "Type", key: "asset_type" },
      { label: "Department", key: "department" }, { label: "Platform", key: "technology_platform" }, { label: "Recorded criticality", key: "existing_criticality" }], a.assets));
  }

  function shap(a) {
    var box = $("p-shap"), t = a.shap.top;
    box.appendChild(el("h2", "SHAP – why the model chose " + a.prediction.label));
    box.appendChild(el("p", "Native CatBoost SHAP for the predicted class. Positive values push toward " + a.prediction.label + ", negative values push away. SHAP explains the existing prediction; it does not make one.", "muted"));
    var cv = el("div", null, "chartbox tall"), c = el("canvas"); cv.appendChild(c); box.appendChild(cv);
    U.barChart(c, t.map(function (r) { return r.feature; }), t.map(function (r) { return r.shap; }), { horizontal: true, fmt: f4, xTitle: "SHAP value" });
    var ck = a.shap.check;
    box.appendChild(el("p", "Check: base value " + f4(ck.base_value) + " + sum of contributions = " + f4(ck.sum_plus_base) + "; CatBoost raw score = " + f4(ck.raw_score) + ".", "muted small"));
    box.appendChild(U.table([{ label: "Feature", key: "feature" }, { label: "Value", key: "value" },
      { label: "SHAP", render: function (r) { return f4(r.shap); } }, { label: "Direction", key: "direction" }], t));
  }

  function lime(a) {
    var box = $("p-lime"), L = a.lime;
    box.appendChild(el("h2", "LIME – local surrogate"));
    box.appendChild(el("p", "CatBoost probability " + f4(L.model_probability) + " · LIME local estimate " + f4(L.local_pred) + " · local fit R² = " + f4(L.r2) + ". A low R² means the local rules only weakly describe the model here.", "muted"));
    var cv = el("div", null, "chartbox tall"), c = el("canvas"); cv.appendChild(c); box.appendChild(cv);
    U.barChart(c, L.table.map(function (r) { return r["local condition"]; }), L.table.map(function (r) { return r.weight; }), { horizontal: true, fmt: f4, xTitle: "LIME weight" });
    box.appendChild(U.table([{ label: "Local condition", key: "local condition" }, { label: "Weight", render: function (r) { return f4(r.weight); } },
      { label: "Direction", key: "direction" }], L.table));
  }

  function compare(a) {
    var box = $("p-compare"), c = a.comparison;
    box.appendChild(el("h2", "Where SHAP and LIME overlap"));
    box.appendChild(el("p", c.both.length + " feature(s) appear in both top-10 lists. Features found by only one method are listed below; disagreement between the methods is normal and should be read with the LIME fit in mind.", "muted"));
    if (c.both.length) box.appendChild(U.table([{ label: "Feature", key: "feature" }, { label: "SHAP direction", key: "shap_direction" },
      { label: "LIME direction", key: "lime_direction" }, { label: "Agree", render: function (r) { return r.agree ? "yes" : "no"; } }], c.both));
    box.appendChild(el("h3", "Only in SHAP top 10")); box.appendChild(el("p", c.only_shap.join(", ") || "(none)"));
    box.appendChild(el("h3", "Only in LIME top 10")); box.appendChild(el("p", c.only_lime.join(", ") || "(none)"));
  }

  function compliance(a) {
    var box = $("p-compliance"), C = a.compliance;
    box.appendChild(el("h2", "Candidate ISO/IEC 27001:2022 Annex A controls"));
    box.appendChild(el("p", C.summary));
    box.appendChild(el("div", "Every item is a candidate for human review. A predicted Medium or High combination does not prove ISO non-compliance.", "warn"));
    if (!C.report_rows.length) { box.appendChild(el("p", "No candidate mappings were produced.")); }
    else {
      var cols = [
        { label: "#", key: "no" }, { label: "Source", key: "source", wrap: 1 }, { label: "Item", key: "item", wrap: 1 },
        { label: "Candidate ISO control", key: "candidate_iso_control", wrap: 1 }, { label: "Fit", key: "fit" },
        { label: "Action and evidence", render: function (r) { return U.details("Show", [["Proposed action", r.proposed_action], ["Evidence required", r.evidence_required], ["Evidence found in data", r.evidence_found_in_data]]); } },
        { label: "Reviewer decision", render: function (r) { return decisionBox(r); } }];
      box.appendChild(U.table(cols, C.report_rows));
    }
    if (C.not_mapped.length) {
      box.appendChild(el("h3", "Factors that could not be mapped"));
      box.appendChild(U.table([{ label: "Risk factor", key: "risk_factor" }, { label: "Explained by", key: "explained_by" }, { label: "Reason", key: "reason", wrap: 1 }], C.not_mapped));
    }
  }
  function decisionBox(r) {
    var w = el("div", null, "decide"), s = el("select"), n = el("textarea"), msg = el("div", "", "muted small");
    s.setAttribute("aria-label", "Reviewer decision for row " + r.no);
    window.DECISIONS.forEach(function (d) { var o = el("option", d); o.value = d; if (d === r.reviewer_decision) o.selected = true; s.appendChild(o); });
    n.value = r.reviewer_notes || ""; n.placeholder = "Reviewer notes"; n.maxLength = 2000;
    function save() {
      U.jpost("/api/assessments/" + window.AID + "/reviews", { row_no: r.no, decision: s.value, notes: n.value }).then(function (x) {
        msg.textContent = x.ok ? "Saved" : (x.data.message || "Not saved");
      });
    }
    s.addEventListener("change", save); n.addEventListener("change", save);
    w.appendChild(s); w.appendChild(n); w.appendChild(msg); return w;
  }

  function features(a) {
    var box = $("p-features");
    box.appendChild(el("h2", "Feature values generated by feature_extraction.compute_features"));
    box.appendChild(U.table([{ label: "#", render: function (r) { return a.features.indexOf(r) + 1; } }, { label: "Feature", key: "feature" }, { label: "Value", key: "value" }], a.features, { cls: "small-table" }));
  }
})();
