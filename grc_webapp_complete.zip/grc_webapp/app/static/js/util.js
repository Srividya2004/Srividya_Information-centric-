window.U = (function () {
  "use strict";
  function el(tag, text, cls) {
    var e = document.createElement(tag);
    if (text !== undefined && text !== null) e.textContent = text;   // textContent only: workbook text is never parsed as HTML
    if (cls) e.className = cls;
    return e;
  }
  function jget(url) { return fetch(url).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, status: r.status, data: d }; }); }); }
  function jpost(url, body) {
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, status: r.status, data: d }; }); });
  }
  function table(cols, rows, opts) {
    opts = opts || {};
    var t = el("table", null, opts.cls || ""), h = el("thead"), hr = el("tr");
    cols.forEach(function (c) { hr.appendChild(el("th", c.label, c.wrap ? "wrap" : "")); });
    h.appendChild(hr); t.appendChild(h);
    var b = el("tbody");
    rows.forEach(function (r) {
      var tr = el("tr");
      cols.forEach(function (c) {
        var td = el("td", null, c.wrap ? "wrap" : "");
        var v = c.render ? c.render(r) : r[c.key];
        if (v instanceof Node) td.appendChild(v); else td.textContent = (v === null || v === undefined) ? "" : String(v);
        tr.appendChild(td);
      });
      b.appendChild(tr);
    });
    t.appendChild(b);
    var w = el("div", null, "tablewrap"); w.appendChild(t); return w;
  }
  function details(summary, pairs) {
    var d = el("details"); d.appendChild(el("summary", summary));
    pairs.forEach(function (p) { var b = el("p", null, "small"); b.appendChild(el("strong", p[0] + ": ")); b.appendChild(document.createTextNode(p[1] || "")); d.appendChild(b); });
    return d;
  }
  function css(v) { return getComputedStyle(document.documentElement).getPropertyValue(v).trim(); }
  function barChart(canvas, labels, values, opts) {
    opts = opts || {};
    var text = css("--fg") || "#222", grid = css("--line") || "#ddd";
    var colors = values.map(function (v) { return opts.colorFn ? opts.colorFn(v) : (v >= 0 ? "#1f5fbf" : "#c0392b"); });
    return new Chart(canvas, { type: "bar",
      data: { labels: labels, datasets: [{ data: values, backgroundColor: colors }] },
      options: { animation: false, indexAxis: opts.horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return (opts.fmt || String)(c.parsed[opts.horizontal ? "x" : "y"]); } } } },
        scales: { x: { ticks: { color: text }, grid: { color: grid }, title: { display: !!opts.xTitle, text: opts.xTitle, color: text } },
                  y: { ticks: { color: text }, grid: { color: grid }, title: { display: !!opts.yTitle, text: opts.yTitle, color: text } } } } });
  }
  function lineChart(canvas, labels, values, xTitle, yTitle) {
    var text = css("--fg") || "#222", grid = css("--line") || "#ddd";
    return new Chart(canvas, { type: "line",
      data: { labels: labels, datasets: [{ data: values, borderColor: "#1f5fbf", backgroundColor: "#1f5fbf", tension: 0.15 }] },
      options: { animation: false, responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
        scales: { x: { ticks: { color: text }, grid: { color: grid }, title: { display: true, text: xTitle, color: text } },
                  y: { ticks: { color: text }, grid: { color: grid }, title: { display: true, text: yTitle, color: text }, beginAtZero: true } } } });
  }
  return { details: details, el: el, jget: jget, jpost: jpost, table: table, barChart: barChart, lineChart: lineChart };
})();
