(function () {
  "use strict";
  var el = U.el, $ = function (id) { return document.getElementById(id); }, chart = null;
  function go() {
    var k = parseInt($("k").value, 10);
    $("status").textContent = " Computing… (the first run builds the inputs, about 10 s)";
    U.jget("/api/coverage?k=" + k).then(function (r) {
      if (!r.ok) { $("status").textContent = " " + (r.data.message || "Error"); return; }
      $("status").textContent = ""; draw(r.data, k);
    });
  }
  function draw(d, k) {
    var u = d.universe, s = d.result, st = $("stats"); st.replaceChildren();
    var dl = el("dl", null, "kv");
    function kv(a, b) { dl.appendChild(el("dt", a)); dl.appendChild(el("dd", b)); }
    kv("Flagged combinations", u.flagged_combinations + " (High " + u.high_flagged + ", Medium " + u.medium_flagged + ")");
    kv("With a mappable gap pair", u.with_mappable_pair + " (" + u.without + " cannot be covered)");
    kv("Control-gap records", u.gap_records + " (" + u.gap_records_unmapped + " excluded: control has no ISO mapping)");
    kv("Candidate actions / pairs to cover", u.candidate_actions + " / " + u.pairs);
    kv("With K = " + k, s.pairs_covered + " pairs covered (" + s.pct + "%)");
    kv("Flagged combinations touched", s.combinations_touched + " of " + u.flagged_combinations + " (High " + s.high_touched + " of " + u.high_flagged + ", Medium " + s.medium_touched + " of " + u.medium_flagged + ")");
    st.appendChild(dl);
    if (chart) chart.destroy();
    chart = U.lineChart($("curve"), d.curve.map(function (c) { return c.step; }), d.curve.map(function (c) { return c.pct; }), "Actions selected (step)", "% of pairs covered");
    var dls = $("dl"); dls.replaceChildren(); var a = el("a", "Download action plan CSV (K=" + k + ")"); a.href = "/coverage/plan.csv?k=" + k; dls.appendChild(a);
    $("plan").replaceChildren(U.table([
      { label: "Step", key: "step" }, { label: "Asset", key: "asset_id" }, { label: "Control", key: "erg_control_name", wrap: 1 },
      { label: "Status", key: "implementation_status", wrap: 1 }, { label: "Candidate ISO controls", key: "candidate_iso_controls", wrap: 1 },
      { label: "Fit", key: "fit" }, { label: "New pairs", key: "new_pairs" }, { label: "Total", key: "total_pairs_covered" }, { label: "%", key: "pct_of_universe" },
      { label: "Details", render: function (r) { return U.details("Show", [["Why this ISO control", r.why_this_iso_control], ["Proposed action", r.proposed_action], ["Evidence to verify", r.evidence_to_verify]]); } },
      { label: "Reviewer decision", render: decisionBox }], d.plan));
  }
  function decisionBox(r) {
    var w = el("div", null, "decide"), s = el("select"), n = el("textarea"), msg = el("div", "", "muted small");
    s.setAttribute("aria-label", "Reviewer decision for " + r.action_id);
    window.DECISIONS.forEach(function (x) { var o = el("option", x); o.value = x; if (x === r.reviewer_decision) o.selected = true; s.appendChild(o); });
    n.value = r.reviewer_notes || ""; n.placeholder = "Reviewer notes"; n.maxLength = 2000;
    function save() { U.jpost("/api/coverage/reviews", { action_id: r.action_id, decision: s.value, notes: n.value }).then(function (x) { msg.textContent = x.ok ? "Saved" : (x.data.message || "Not saved"); }); }
    s.addEventListener("change", save); n.addEventListener("change", save);
    w.appendChild(s); w.appendChild(n); w.appendChild(msg); return w;
  }
  $("go").addEventListener("click", go); go();
})();
