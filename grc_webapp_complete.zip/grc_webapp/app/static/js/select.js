(function () {
  "use strict";
  var MAX = 4, PAGE = 25, offset = 0, total = 0, timer = null, sel = [];
  var $ = function (id) { return document.getElementById(id); }, el = U.el;

  function load() {
    var p = new URLSearchParams({ q: $("q").value, asset_type: $("type").value,
                                  department: $("dept").value, limit: PAGE, offset: offset });
    fetch("/api/inventory/search?" + p).then(function (r) { return r.json(); }).then(function (d) {
      total = d.total;
      var body = $("rows"); body.replaceChildren();
      d.results.forEach(function (a) {
        var tr = el("tr");
        [a.asset_id, a.asset_name, a.asset_type, a.department, a.existing_criticality].forEach(function (v) { tr.appendChild(el("td", v || "")); });
        var td = el("td"), b = el("button", sel.indexOf(a.asset_id) >= 0 ? "Added" : "Add");
        b.type = "button"; b.disabled = sel.indexOf(a.asset_id) >= 0 || sel.length >= MAX;
        b.addEventListener("click", function () { add(a.asset_id); });
        td.appendChild(b); tr.appendChild(td); body.appendChild(tr);
      });
      $("count").textContent = total + " matching Low-criticality assets";
      $("page").textContent = total ? "Showing " + (offset + 1) + "–" + Math.min(offset + PAGE, total) : "No matches";
      $("prev").disabled = offset === 0; $("next").disabled = offset + PAGE >= total;
    });
  }
  function add(id) { if (sel.indexOf(id) < 0 && sel.length < MAX) { sel.push(id); drawTray(); load(); } }
  function remove(id) { sel = sel.filter(function (x) { return x !== id; }); drawTray(); load(); }
  function drawTray() {
    var ul = $("tray"); ul.replaceChildren();
    sel.forEach(function (id) {
      var li = el("li"); li.appendChild(el("span", id));
      var b = el("button", "Remove"); b.type = "button"; b.addEventListener("click", function () { remove(id); });
      li.appendChild(b); ul.appendChild(li);
    });
    $("n").textContent = "(" + sel.length + "/" + MAX + ")";
    $("typed").value = sel.join(", ");
    $("run").disabled = true; $("result").replaceChildren();
  }
  function show(ok, title, lines) {
    var box = el("div", null, "msg " + (ok ? "ok" : "bad")); box.appendChild(el("strong", title));
    if (lines && lines.length) { var ul = el("ul"); lines.forEach(function (l) { ul.appendChild(el("li", l)); }); box.appendChild(ul); }
    $("result").replaceChildren(box);
  }
  function validate() {
    U.jpost("/api/selection/validate", { asset_ids: $("typed").value }).then(function (r) {
      var d = r.data;
      if (d.valid) {
        sel = d.asset_ids.slice(); var typed = $("typed").value; drawTray(); $("typed").value = typed; load();
        show(true, "Selection is valid (checked by the server)",
             d.assets.map(function (a) { return a.asset_id + " – " + a.asset_name + " (" + a.asset_type + ", " + a.existing_criticality + ")"; }));
        $("run").disabled = false;
      } else { show(false, "Selection is not valid", d.errors.map(function (e) { return e.message; })); $("run").disabled = true; }
    });
  }
  function run() {
    $("run").disabled = true; $("runmsg").textContent = "Running prediction, SHAP, LIME and ISO mapping… about 5–10 seconds.";
    U.jpost("/api/assessments", { asset_ids: $("typed").value }).then(function (r) {
      if (r.ok) { window.location = r.data.url; return; }
      $("runmsg").textContent = ""; $("run").disabled = false;
      show(false, "The server rejected this selection", (r.data.errors || [{ message: r.data.message || "Error" }]).map(function (e) { return e.message; }));
    }).catch(function () { $("runmsg").textContent = "Could not reach the server."; $("run").disabled = false; });
  }
  $("q").addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { offset = 0; load(); }, 250); });
  $("type").addEventListener("change", function () { offset = 0; load(); });
  $("dept").addEventListener("change", function () { offset = 0; load(); });
  $("prev").addEventListener("click", function () { offset = Math.max(0, offset - PAGE); load(); });
  $("next").addEventListener("click", function () { offset += PAGE; load(); });
  $("validate").addEventListener("click", validate);
  $("run").addEventListener("click", run);
  $("typed").addEventListener("input", function () { $("run").disabled = true; });
  $("clear").addEventListener("click", function () { sel = []; drawTray(); load(); });
  drawTray(); load();
})();
