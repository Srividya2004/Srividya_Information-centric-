"""Orchestrates one full assessment: validate -> predict -> SHAP -> LIME -> ISO candidates -> save."""
import json
import threading

import numpy as np

import config


class InvalidSelection(Exception):
    def __init__(self, result):
        self.result = result


def _py(o):
    if hasattr(o, "item"):
        return o.item()
    return str(o)


class AssessmentService:
    def __init__(self, inventory, model, compliance, store):
        self.inventory, self.model, self.compliance, self.store = inventory, model, compliance, store
        self._lock = threading.Lock()

    def run(self, raw_ids):
        v = self.inventory.validate_selection(raw_ids)           # backend validation, always
        if not v["valid"]:
            raise InvalidSelection(v)
        ids = v["asset_ids"]
        with self._lock:
            a = self.model.assess(ids)
            label, ci, row = a["label"], a["pred_index"], a["row"]
            shap_t, shap_chk = self.model.shap_table(row, ci, label)
            lime_t, lime_m = self.model.lime_table(row, ci, label)
            prob = a["probabilities"][label]
            comp = self.compliance.map_assessment(ids, label, prob, shap_t, lime_t,
                                                  a["raw_features"], self.model.feature_cols)

        top = shap_t.reindex(shap_t["shap"].abs().sort_values(ascending=False).index).head(config.SHAP_TOP_N)
        shap_dir, lime_dir = dict(zip(top["feature"], top["direction"])), dict(zip(lime_t["feature"], lime_t["direction"]))
        both = [f for f in top["feature"] if f in lime_dir]
        comparison = {
            "both": [{"feature": f, "shap_direction": shap_dir[f], "lime_direction": lime_dir[f],
                      "agree": shap_dir[f] == lime_dir[f]} for f in both],
            "only_shap": [f for f in shap_dir if f not in lime_dir],
            "only_lime": [f for f in lime_dir if f not in shap_dir]}
        warnings = []
        if lime_m["r2"] < config.LIME_R2_WARN_BELOW:
            warnings.append(f"LIME's local fit is weak (R² = {lime_m['r2']:.3f}, below {config.LIME_R2_WARN_BELOW}). "
                            "Treat the LIME conditions as weak evidence; SHAP is the primary explanation here.")
        if a["dataset_record"]["seen_in_training_set"]:
            d = a["dataset_record"]
            warnings.append(f"This exact combination is in the 14,000 generated combinations "
                            f"({d['combination_id']}, {d['split']} split), so this is not a new, unseen combination.")
        warnings.append("The dataset labels are rule-based, so a high model score shows agreement with those "
                        "rules, not real-world accuracy.")

        result = {
            "asset_ids": ids, "assets": v["assets"],
            "prediction": {"label": label, "probabilities": a["probabilities"], "dataset_record": a["dataset_record"],
                           "model_input_shape": list(row.shape)},
            "features": [{"feature": k, "value": val} for k, val in a["raw_features"].items()],
            "shap": {"table": json.loads(shap_t.to_json(orient="records")), "top": json.loads(top.to_json(orient="records")),
                     "check": shap_chk},
            "lime": {"table": json.loads(lime_t.to_json(orient="records")), "r2": lime_m["r2"],
                     "local_pred": lime_m["local_pred"], "model_probability": prob},
            "comparison": comparison, "compliance": comp, "warnings": warnings,
            "model_checks": self.model.startup_checks,
        }
        result = json.loads(json.dumps(result, default=_py))       # make everything JSON-safe
        self.store.save_assessment(result)
        return result
