"""
Phases 2-3: prediction + SHAP + LIME for ONE selected combination.

Everything here follows the cells of GRC_Pro_clean.ipynb that you actually executed:
  cell 7-10  build the 71-column training matrix  (sheets 05, 06, 11; get_dummies on 5 text columns)
  cell 26    compute_features -> prepare_inference_row           (reused modules, unchanged)
  cell 27    predict_proba, label via the label encoder
  cell 29    SHAP = CatBoost native  get_feature_importance(Pool, type="ShapValues")
  cell 30    LIME = LimeTabularExplainer, 300-row background, seed 42, 10 features, 3000 samples
It does NOT call explain.py / report.py / demo.py, and it does not train anything.
"""
import numpy as np
import pandas as pd
from catboost import Pool

import config


class SchemaMismatch(RuntimeError):
    pass


class ModelService:
    def __init__(self, inv, erg_path=None, model_path=None):
        from model_utils import load_model, prepare_inference_row   # research module, unchanged
        self._prepare = prepare_inference_row
        self.inv = inv
        self.erg_path = str(erg_path or config.ERG_PATH)
        self.bundle = load_model(str(model_path or config.MODEL_PATH))
        self.model = self.bundle["model"]
        self.le = self.bundle["label_encoder"]
        self.feature_cols = list(self.bundle["feature_cols"])
        self._build_training_matrix()
        self.startup_checks = self._check_schema()
        self._lime_background = None

    # ---------- notebook cells 7-10 ----------
    def _build_training_matrix(self):
        p = self.erg_path
        features = pd.read_excel(p, sheet_name="05_Combination_Features")
        labels = pd.read_excel(p, sheet_name="06_Combined_Criticality_Labels")
        splits = pd.read_excel(p, sheet_name="11_Model_TrainTest_Split")
        df = features.merge(labels, on="combination_id").merge(splits, on="combination_id")
        not_features = ["combination_id", "combined_criticality", "split"]
        raw_cols = [c for c in df.columns if c not in not_features]
        cat_cols = [c for c in df.select_dtypes(include="object").columns if c not in not_features]
        bool_cols = df.select_dtypes(include="bool").columns.tolist()
        df_enc = pd.get_dummies(df, columns=cat_cols, drop_first=False)
        self.nb_feature_cols = [c for c in df_enc.columns if c not in not_features]
        self.new_columns = [c for c in self.nb_feature_cols if c not in raw_cols]
        self.nb_cat_cols, self.nb_bool_cols = cat_cols, bool_cols
        self.labels_df = labels
        self.splits_df = splits
        self.df_enc = df_enc
        self.X_train = df_enc.loc[df_enc["split"] == "train", self.nb_feature_cols]
        self.X_test = df_enc.loc[df_enc["split"] == "test", self.nb_feature_cols]
        self.y_test = self.le.transform(df_enc.loc[df_enc["split"] == "test", "combined_criticality"])
        self.combo_info = {frozenset(a.strip() for a in ids.split(",")): cid
                           for cid, ids in zip(self.inv.existing_combos_df.combination_id,
                                               self.inv.existing_combos_df.asset_ids)}
        self.label_by_combo = dict(zip(labels.combination_id, labels.combined_criticality))
        self.split_by_combo = dict(zip(splits.combination_id, splits.split))

    # ---------- schema check (fails loudly at startup) ----------
    def _check_schema(self):
        checks = {}
        def chk(name, ok, detail=""):
            checks[name] = {"ok": bool(ok), "detail": str(detail)}
            if not ok:
                raise SchemaMismatch(f"Model/schema check failed: {name} {detail}")
        chk("bundle feature_cols == columns rebuilt from workbook", self.feature_cols == self.nb_feature_cols,
            f"{len(self.feature_cols)} columns")
        chk("CatBoost feature_names_ == bundle feature_cols", list(self.model.feature_names_) == self.feature_cols)
        chk("bundle cat_cols == workbook text columns", list(self.bundle["cat_cols"]) == self.nb_cat_cols,
            self.nb_cat_cols)
        chk("class order is High, Low, Medium", list(self.le.classes_) == ["High", "Low", "Medium"],
            list(self.le.classes_))
        acc = float(self.model.score(self.X_test, self.y_test))
        stored = float(self.bundle.get("test_accuracy", float("nan")))
        chk("recomputed test accuracy == stored test accuracy", abs(acc - stored) < 1e-9,
            f"{acc:.10f} vs {stored:.10f}")
        checks["test_accuracy"] = {"ok": True, "detail": f"{acc:.4f}"}
        return checks

    # ---------- notebook cells 26-27 ----------
    def assess(self, asset_ids):
        from feature_extraction import compute_features        # research module, unchanged
        raw = compute_features(list(asset_ids), self.inv)
        row = self._prepare(raw, self.bundle)
        if list(row.columns) != self.feature_cols or int(row.isna().sum().sum()) != 0:
            raise SchemaMismatch("Prepared row does not match the model schema.")
        proba = self.model.predict_proba(row)[0]
        pred_index = int(np.array(self.model.predict(row)).ravel()[0])
        label = str(self.le.inverse_transform([pred_index])[0])
        probs = {str(c): float(p) for c, p in zip(self.le.classes_, proba)}
        cid = self.combo_info.get(frozenset(asset_ids))
        seen = {"seen_in_training_set": cid is not None, "combination_id": cid,
                "split": self.split_by_combo.get(cid), "stored_label": self.label_by_combo.get(cid)}
        return {"raw_features": raw, "row": row, "label": label, "pred_index": pred_index,
                "probabilities": probs, "dataset_record": seen}

    # ---------- notebook cell 29 ----------
    def shap_table(self, row, class_index, label):
        sv = self.model.get_feature_importance(Pool(row), type="ShapValues")
        contrib, base = sv[0, class_index, :-1], float(sv[0, class_index, -1])
        raw_score = float(self.model.predict(row, prediction_type="RawFormulaVal")[0][class_index])
        t = pd.DataFrame({"feature": self.feature_cols, "value": row.iloc[0].values, "shap": contrib})
        t["direction"] = np.where(t["shap"] > 0, "toward " + label, "away from " + label)
        return t, {"base_value": base, "sum_plus_base": base + float(contrib.sum()), "raw_score": raw_score}

    # ---------- notebook cell 30 ----------
    def _explainer(self):
        """A FRESH explainer per call. LimeTabularExplainer keeps a random state that advances on
        every explanation, so reusing one instance would make repeated runs differ. A fresh one
        with random_state=42 reproduces the notebook result every time."""
        from lime.lime_tabular import LimeTabularExplainer
        if getattr(self, "_lime_background", None) is None:
            self._lime_background = self.X_train.sample(config.LIME_BACKGROUND_ROWS,
                                                        random_state=config.LIME_RANDOM_STATE)
            self._lime_positions = [self.feature_cols.index(c) for c in self.new_columns]
        return LimeTabularExplainer(
            training_data=self._lime_background.values.astype(float), feature_names=self.feature_cols,
            class_names=list(self.le.classes_), categorical_features=self._lime_positions,
            mode="classification", random_state=config.LIME_RANDOM_STATE)

    def lime_table(self, row, class_index, label):
        def probs(rows):
            return self.model.predict_proba(pd.DataFrame(rows, columns=self.feature_cols))
        res = self._explainer().explain_instance(
            row.iloc[0].values.astype(float), probs, labels=(class_index,),
            num_features=config.LIME_NUM_FEATURES, num_samples=config.LIME_NUM_SAMPLES)
        t = pd.DataFrame(res.as_list(label=class_index), columns=["local condition", "weight"])
        t["direction"] = np.where(t["weight"] > 0, "toward " + label, "away from " + label)
        feats = []
        for rule in t["local condition"]:                       # notebook cell 31
            m = [f for f in self.feature_cols if f in rule]
            feats.append(max(m, key=len))
        t["feature"] = feats
        return t, {"local_pred": float(res.local_pred[0]), "r2": float(res.score)}
