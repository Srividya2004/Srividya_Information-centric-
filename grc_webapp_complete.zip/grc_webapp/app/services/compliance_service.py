"""
Phases 4-5: candidate ISO mapping for one assessment, and portfolio-level Maximum Coverage.
Wraps research/compliance_mapper.py (unchanged). Follows notebook cells 43-48.
All outputs are CANDIDATES for human review - nothing here claims compliance.
"""
import json
import threading

import pandas as pd

import config


def records(df):
    """DataFrame -> list of JSON-safe dicts (NaN -> null, numpy -> python)."""
    if df is None or len(df) == 0:
        return []
    return json.loads(df.to_json(orient="records"))


class ComplianceService:
    def __init__(self, inv, labels_df):
        import compliance_mapper as cm
        self.cm, self.inv, self.labels_df = cm, inv, labels_df
        self._cov = None
        self._lock = threading.Lock()
        self.iso_title = cm.get_iso_reference().set_index("iso_control_id")["iso_control_title"].to_dict()
        self.why_by_control = cm.get_erg_control_to_iso().set_index("erg_control_name")["mapping_rationale"].to_dict()

    # ---------- notebook cells 43-44 ----------
    def map_assessment(self, asset_ids, label, probability, shap_table, lime_table, raw_features, feature_cols):
        rep = self.cm.map_to_iso(asset_ids=asset_ids, predicted_label=label, probability=probability,
                                 shap_table=shap_table, lime_table=lime_table, inv=self.inv,
                                 feature_values=raw_features, feature_names=feature_cols)
        rec, ev = rep["recommendations"], rep["asset_evidence"]
        rows = []
        for _, r in rec.iterrows():
            found = [str(e["scope"]) + ": " + e["observation"] for _, e in ev.iterrows()
                     if r["risk_factor"] in str(e["risk_factor"]).split(", ")]
            rows.append({"source": "Risk factor (" + r["explained_by"] + ")", "item": r["risk_factor"],
                         "candidate_iso_control": r["iso_control_id"] + " " + r["iso_control_title"],
                         "fit": r["fit"], "proposed_action": r["proposed_action"],
                         "evidence_required": r["evidence_required"],
                         "evidence_found_in_data": "; ".join(found) if found else "(none found)"})
        for _, g in rep["control_record_candidates"].iterrows():
            rows.append({"source": "Control record (02e_Controls)",
                         "item": g["asset_id"] + " - " + g["erg_control_name"] + " (" + g["implementation_status"]
                                 + ", effectiveness " + str(g["control_effectiveness"]) + ")",
                         "candidate_iso_control": g["candidate_iso_ids"], "fit": g["fit"],
                         "proposed_action": "Review why this control is rated Low effectiveness on this asset and whether it applies.",
                         "evidence_required": "Implementation and effectiveness record for this control on this asset.",
                         "evidence_found_in_data": "Dataset records implementation status: " + g["implementation_status"]})
        for i, r in enumerate(rows, 1):
            r["no"] = i
            r["status"] = "Candidate - needs human review"
        return {"summary": rep["summary"], "caution": rep.get("caution", ""),
                "recommendations": records(rec), "asset_evidence": records(ev),
                "control_records": records(rep["control_record_candidates"]),
                "not_mapped": records(rep["not_mapped"]), "report_rows": rows}

    # ---------- notebook cells 46-48 ----------
    def coverage_inputs(self):
        with self._lock:
            if self._cov is None:
                self._cov = self.cm.build_coverage_inputs(self.inv, self.inv.existing_combos_df, self.labels_df)
            return self._cov

    def coverage(self, k):
        cov = self.coverage_inputs()
        sel = self.cm.greedy_max_coverage(cov, k)
        n_high = sum(1 for v in cov["label_of"].values() if v == "High")
        last = sel.iloc[-1]
        plan = sel.copy()
        plan["candidate_iso_controls"] = plan["iso_ids"].apply(
            lambda ids: "; ".join(i + " " + self.iso_title[i] for i in ids.split("; ")))
        plan["why_this_iso_control"] = plan["erg_control_name"].map(self.why_by_control)
        plan["proposed_action"] = ("Review the " + plan["erg_control_name"] + " control on " + plan["asset_id"]
                                   + " (recorded as " + plan["implementation_status"]
                                   + ", Low effectiveness) and decide whether to improve or confirm it.")
        plan["evidence_to_verify"] = ("Implementation and effectiveness record for " + plan["erg_control_name"]
                                      + " on " + plan["asset_id"] + "; confirm the candidate ISO control text applies.")
        return {
            "k": int(k),
            "universe": {"flagged_combinations": cov["n_flagged"],
                         "with_mappable_pair": cov["n_flagged_with_pair"],
                         "without": cov["n_flagged"] - cov["n_flagged_with_pair"],
                         "gap_records": cov["n_gap_records"],
                         "gap_records_unmapped": cov["n_gap_records_unmapped"],
                         "candidate_actions": int(len(cov["actions"])),
                         "pairs": len(cov["universe"]),
                         "high_flagged": n_high, "medium_flagged": cov["n_flagged"] - n_high},
            "result": {"actions_selected": int(len(sel)), "pairs_covered": int(last["total_pairs_covered"]),
                       "pct": float(last["pct_of_universe"]),
                       "combinations_touched": int(last["combinations_touched"]),
                       "high_touched": int(last["high_touched"]), "medium_touched": int(last["medium_touched"])},
            "plan": records(plan),
            "curve": [{"step": int(r.step), "pct": float(r.pct_of_universe)} for r in sel.itertuples()],
        }
