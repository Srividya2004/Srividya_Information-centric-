"""Phase 6: PDF and CSV reports built from a saved assessment (never from anything not on screen)."""
import csv
import io
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle, PageBreak

CAUTION = ("Every mapping below is a CANDIDATE for human review. A predicted Medium or High combination "
           "does not prove ISO/IEC 27001:2022 non-compliance, and 'covered' never means 'compliant'.")


def csv_bytes(res):
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["no", "source", "item", "candidate_iso_control", "fit", "proposed_action", "evidence_required",
                "evidence_found_in_data", "status", "reviewer_decision", "reviewer_notes"])
    for r in res["compliance"]["report_rows"]:
        w.writerow([r["no"], r["source"], r["item"], r["candidate_iso_control"], r["fit"], r["proposed_action"],
                    r["evidence_required"], r["evidence_found_in_data"], r["status"],
                    r.get("reviewer_decision", "Pending"), r.get("reviewer_notes", "")])
    return out.getvalue().encode("utf-8-sig")        # BOM so Excel opens it correctly


def coverage_csv_bytes(cov, reviews):
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["step", "action_id", "asset_id", "erg_control_name", "implementation_status", "candidate_iso_controls",
                "fit", "new_pairs", "total_pairs_covered", "pct_of_universe", "proposed_action", "evidence_to_verify",
                "status", "reviewer_decision", "reviewer_notes"])
    for r in cov["plan"]:
        rv = reviews.get(r["action_id"], {})
        w.writerow([r["step"], r["action_id"], r["asset_id"], r["erg_control_name"], r["implementation_status"],
                    r["candidate_iso_controls"], r["fit"], r["new_pairs"], r["total_pairs_covered"],
                    r["pct_of_universe"], r["proposed_action"], r["evidence_to_verify"], r["status"],
                    rv.get("decision", "Pending"), rv.get("notes", "")])
    return out.getvalue().encode("utf-8-sig")


def pdf_bytes(res):
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm,
                            title=f"Risk assessment {res['id']}", author="GRC Contextual Risk Assessment")
    ss = getSampleStyleSheet()
    h1, h2 = ss["Title"], ss["Heading2"]
    body = ParagraphStyle("b", parent=ss["BodyText"], fontSize=9, leading=12)
    small = ParagraphStyle("s", parent=body, fontSize=7.5, leading=9.5)
    P = lambda t, st=small: Paragraph(escape(str(t)), st)

    def table(data, widths, header=True):
        t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
        t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
                               ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8edf5")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3)]))
        return t

    pred = res["prediction"]
    s = [Paragraph("Contextual Risk Assessment of a Low-Criticality Asset Combination", h1),
         P(f"Assessment #{res['id']} - {res['created_at']} (UTC)", body), Spacer(1, 4),
         Paragraph("Selected assets", h2),
         table([[P("ID"), P("Name"), P("Type"), P("Department"), P("Recorded criticality")]] +
               [[P(a["asset_id"]), P(a["asset_name"]), P(a["asset_type"]), P(a.get("department")),
                 P(a["existing_criticality"])] for a in res["assets"]], [30 * mm, 60 * mm, 50 * mm, 40 * mm, 40 * mm]),
         Paragraph("Prediction (CatBoost)", h2),
         P(f"Predicted class: {pred['label']}. Probabilities: " +
           ", ".join(f"{k} {v:.1%}" for k, v in pred['probabilities'].items()), body)]
    for w in res["warnings"]:
        s.append(P("Note: " + w, body))
    s += [Paragraph("Top SHAP contributions (native CatBoost SHAP)", h2),
          table([[P("Feature"), P("Value"), P("SHAP"), P("Direction")]] +
                [[P(r["feature"]), P(r["value"]), P(f"{r['shap']:.4f}"), P(r["direction"])] for r in res["shap"]["top"]],
                [80 * mm, 35 * mm, 30 * mm, 60 * mm]),
          Paragraph("LIME local conditions", h2),
          P(f"LIME local fit R2 = {res['lime']['r2']:.4f}; CatBoost probability = {res['lime']['model_probability']:.4f}; "
            f"LIME local estimate = {res['lime']['local_pred']:.4f}.", body),
          table([[P("Condition"), P("Weight"), P("Direction")]] +
                [[P(r["local condition"]), P(f"{r['weight']:.4f}"), P(r["direction"])] for r in res["lime"]["table"]],
                [100 * mm, 30 * mm, 60 * mm]),
          PageBreak(), Paragraph("Candidate ISO/IEC 27001:2022 Annex A controls for human review", h2),
          P(res["compliance"]["summary"], body), P(CAUTION, body), Spacer(1, 4)]
    rows = res["compliance"]["report_rows"]
    if rows:
        s.append(table([[P("#"), P("Source"), P("Item"), P("Candidate ISO control"), P("Fit"), P("Proposed action"),
                         P("Evidence required"), P("Evidence found in data"), P("Reviewer decision / notes")]] +
                       [[P(r["no"]), P(r["source"]), P(r["item"]), P(r["candidate_iso_control"]), P(r["fit"]),
                         P(r["proposed_action"]), P(r["evidence_required"]), P(r["evidence_found_in_data"]),
                         P(r.get("reviewer_decision", "Pending") + (" - " + r["reviewer_notes"] if r.get("reviewer_notes") else ""))]
                        for r in rows],
                       [7 * mm, 24 * mm, 36 * mm, 34 * mm, 12 * mm, 46 * mm, 38 * mm, 38 * mm, 26 * mm]))
    else:
        s.append(P("No candidate mappings were produced for this combination.", body))
    s += [Paragraph("Method notes", h2),
          P("Prediction: CatBoost (400 iterations, depth 6, learning rate 0.08, seed 42) trained on 9,799 of 14,000 "
            "generated combinations whose Low/Medium/High labels are rule-based. SHAP is CatBoost's native value; "
            "LIME uses a 300-row training background and 3,000 samples with seed 42. ISO mappings come from "
            "compliance_mapper.py and are candidates only.", body)]
    doc.build(s)
    return buf.getvalue()
