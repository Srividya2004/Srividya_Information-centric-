"""SQLite history (Phase 7): saved assessments and the reviewer's decisions."""
import json
import sqlite3
from datetime import datetime, timezone

import config

DECISIONS = ["Pending", "Accepted", "Rejected", "Needs more evidence"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS assessments(
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, asset_ids TEXT NOT NULL,
  predicted_label TEXT NOT NULL, probability REAL NOT NULL, result_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reviews(
  assessment_id INTEGER NOT NULL, row_no INTEGER NOT NULL, decision TEXT NOT NULL, notes TEXT NOT NULL,
  updated_at TEXT NOT NULL, PRIMARY KEY(assessment_id, row_no));
CREATE TABLE IF NOT EXISTS coverage_reviews(
  action_id TEXT PRIMARY KEY, decision TEXT NOT NULL, notes TEXT NOT NULL, updated_at TEXT NOT NULL);
"""


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Store:
    def __init__(self, path=None):
        self.path = str(path or config.DB_PATH)
        if self.path != ":memory:":
            import os
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._mem = sqlite3.connect(":memory:", check_same_thread=False) if self.path == ":memory:" else None
        with self._c() as c:
            c.executescript(SCHEMA)

    def _c(self):
        return self._mem if self._mem is not None else sqlite3.connect(self.path)

    def save_assessment(self, result):
        c = self._c()
        cur = c.execute("INSERT INTO assessments(created_at,asset_ids,predicted_label,probability,result_json)"
                        " VALUES(?,?,?,?,?)",
                        (_now(), ",".join(result["asset_ids"]), result["prediction"]["label"],
                         result["prediction"]["probabilities"][result["prediction"]["label"]], "{}"))
        aid = cur.lastrowid
        result["id"], result["created_at"] = aid, _now()
        c.execute("UPDATE assessments SET result_json=?, created_at=? WHERE id=?",
                  (json.dumps(result), result["created_at"], aid))
        c.commit()
        if self._mem is None:
            c.close()
        return aid

    def get_assessment(self, aid):
        c = self._c()
        row = c.execute("SELECT result_json FROM assessments WHERE id=?", (aid,)).fetchone()
        if row is None:
            if self._mem is None: c.close()
            return None
        res = json.loads(row[0])
        rv = {r[0]: {"decision": r[1], "notes": r[2]} for r in
              c.execute("SELECT row_no,decision,notes FROM reviews WHERE assessment_id=?", (aid,))}
        if self._mem is None: c.close()
        for r in res["compliance"]["report_rows"]:
            r["reviewer_decision"] = rv.get(r["no"], {}).get("decision", "Pending")
            r["reviewer_notes"] = rv.get(r["no"], {}).get("notes", "")
        return res

    def history(self, limit=200):
        c = self._c()
        rows = c.execute("SELECT id,created_at,asset_ids,predicted_label,probability FROM assessments"
                         " ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        if self._mem is None: c.close()
        return [{"id": r[0], "created_at": r[1], "asset_ids": r[2].split(","),
                 "predicted_label": r[3], "probability": r[4]} for r in rows]

    def set_review(self, aid, row_no, decision, notes):
        c = self._c()
        c.execute("INSERT INTO reviews(assessment_id,row_no,decision,notes,updated_at) VALUES(?,?,?,?,?)"
                  " ON CONFLICT(assessment_id,row_no) DO UPDATE SET decision=excluded.decision,"
                  " notes=excluded.notes, updated_at=excluded.updated_at",
                  (aid, row_no, decision, notes, _now()))
        c.commit()
        if self._mem is None: c.close()

    def set_coverage_review(self, action_id, decision, notes):
        c = self._c()
        c.execute("INSERT INTO coverage_reviews(action_id,decision,notes,updated_at) VALUES(?,?,?,?)"
                  " ON CONFLICT(action_id) DO UPDATE SET decision=excluded.decision, notes=excluded.notes,"
                  " updated_at=excluded.updated_at", (action_id, decision, notes, _now()))
        c.commit()
        if self._mem is None: c.close()

    def coverage_reviews(self):
        c = self._c()
        d = {r[0]: {"decision": r[1], "notes": r[2]} for r in
             c.execute("SELECT action_id,decision,notes FROM coverage_reviews")}
        if self._mem is None: c.close()
        return d
