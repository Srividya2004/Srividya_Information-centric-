"""
Phase 1 service: search the real inventory and validate asset selections.

It WRAPS research/data_loader.EnterpriseInventory (reused unchanged). Eligibility is
defined by the same rule your notebook and data_loader use:
    risk_df.existing_criticality == "Low"      (inv.low_asset_ids, 649 assets)
Nothing is re-labelled, re-scored or re-derived here.
"""
import re
import config

# IDs in the workbook all look like AST0001. We do NOT reject on format alone
# (the workbook is the authority), but we cap length and character set so odd input
# is reported as "not found" without being echoed raw.
_SAFE_ID = re.compile(r"^[A-Za-z0-9_\-]{1,%d}$" % config.MAX_ID_LEN)

CATALOGUE_COLUMNS = ["asset_id", "asset_name", "asset_type", "asset_subtype",
                     "department", "technology_platform", "environment"]


class InventoryService:
    def __init__(self, inv):
        self.inv = inv
        self._build_catalogue()
        self._check_integrity()

    @classmethod
    def from_workbook(cls, path):
        from data_loader import EnterpriseInventory   # research module, unchanged
        return cls(EnterpriseInventory(str(path)))

    # ---------- setup ----------
    def _build_catalogue(self):
        a = self.inv.assets_df
        crit = self.inv.risk_df[["asset_id", "existing_criticality"]]
        cat = a.merge(crit, on="asset_id", how="left", validate="one_to_one")
        cat["eligible"] = cat["asset_id"].isin(self.inv.low_asset_ids)
        self.catalogue = cat.sort_values("asset_id").reset_index(drop=True)
        self._by_id = self.catalogue.set_index("asset_id")
        # lower-cased text used by the search box (id, name, type, subtype, department, platform)
        self._hay = (self.catalogue[["asset_id", "asset_name", "asset_type", "asset_subtype",
                                     "department", "technology_platform"]]
                     .fillna("").astype(str).agg(" ".join, axis=1).str.lower())

    def _check_integrity(self):
        c = self.catalogue
        problems = []
        if not c["asset_id"].is_unique:
            problems.append("duplicate asset_id in 01_Enterprise_Assets")
        if c["existing_criticality"].isna().any():
            problems.append("assets without an existing_criticality record")
        missing = [a for a in self.inv.low_asset_ids if a not in self.inv.risk_lookup]
        if missing:
            problems.append(f"{len(missing)} Low assets missing from risk lookup")
        if problems:
            raise RuntimeError("Inventory integrity check failed: " + "; ".join(problems))

    # ---------- read APIs ----------
    def summary(self):
        c = self.catalogue
        el = c[c["eligible"]]
        return {
            "total_assets": int(len(c)),
            "by_criticality": {k: int(v) for k, v in c["existing_criticality"].value_counts().items()},
            "eligible_low_assets": int(len(el)),
            "eligible_by_type": {k: int(v) for k, v in el["asset_type"].value_counts().items()},
            "eligible_departments": sorted(el["department"].dropna().unique().tolist()),
            "min_assets": config.MIN_ASSETS,
            "max_assets": config.MAX_ASSETS,
        }

    @staticmethod
    def _row(r):
        return {k: (None if r[k] != r[k] else r[k]) for k in CATALOGUE_COLUMNS} | {
            "existing_criticality": r["existing_criticality"]}

    def search(self, q="", asset_type=None, department=None,
               limit=config.SEARCH_DEFAULT_LIMIT, offset=0):
        """Search ELIGIBLE (Low) assets only. Non-Low assets are never returned."""
        q = (q or "").strip().lower()[: config.SEARCH_MAX_QUERY_LEN]
        limit = max(1, min(int(limit), config.SEARCH_MAX_LIMIT))
        offset = max(0, int(offset))
        mask = self.catalogue["eligible"]
        if q:
            for term in q.split():                      # every word must match (AND)
                mask = mask & self._hay.str.contains(re.escape(term), regex=True)
        if asset_type:
            mask = mask & (self.catalogue["asset_type"] == asset_type)
        if department:
            mask = mask & (self.catalogue["department"] == department)
        hits = self.catalogue[mask]
        page = hits.iloc[offset: offset + limit]
        return {
            "total": int(len(hits)), "limit": limit, "offset": offset,
            "results": [self._row(r) for _, r in page.iterrows()],
        }

    def get_asset(self, asset_id):
        """Returns (status, payload). status: 'ok' | 'not_found' | 'ineligible'."""
        aid = self.normalise_id(asset_id)
        if aid is None or aid not in self._by_id.index:
            return "not_found", None
        r = self._by_id.loc[aid]
        d = {"asset_id": aid} | {k: (None if r[k] != r[k] else r[k]) for k in CATALOGUE_COLUMNS[1:]}
        d["existing_criticality"] = r["existing_criticality"]
        if not bool(r["eligible"]):
            return "ineligible", d
        d["summary"] = self.inv.asset_summary(aid)      # data_loader's own method
        return "ok", d

    # ---------- validation ----------
    @staticmethod
    def normalise_id(x):
        if not isinstance(x, str):
            return None
        x = x.strip().upper()
        return x if _SAFE_ID.match(x) else None

    def validate_selection(self, raw):
        """
        Same rules as the notebook selection cell, enforced on the backend:
          * between MIN_ASSETS and MAX_ASSETS assets
          * no duplicates (after trimming and upper-casing)
          * every asset exists AND is Low-criticality
        `raw` is a list of strings or one comma-separated string.
        Returns {"valid": bool, "asset_ids": [...], "assets": [...], "errors": [...]}.
        """
        errors = []

        def err(code, message, asset_id=None):
            e = {"code": code, "message": message}
            if asset_id is not None:
                e["asset_id"] = asset_id
            errors.append(e)

        if isinstance(raw, str):
            items = [p for p in raw.split(",")]
        elif isinstance(raw, list):
            items = raw
        else:
            err("bad_input", "asset_ids must be a list of IDs or a comma-separated string.")
            return {"valid": False, "asset_ids": [], "assets": [], "errors": errors}

        if len(items) > config.MAX_INPUT_ITEMS:
            err("too_many", f"At most {config.MAX_ASSETS} assets may be selected "
                            f"({len(items)} supplied).")
            return {"valid": False, "asset_ids": [], "assets": [], "errors": errors}

        cleaned, supplied = [], 0
        for it in items:
            if isinstance(it, str) and not it.strip():
                continue                                   # ignore blanks from "A,,B" / trailing comma
            supplied += 1
            if not isinstance(it, str):
                err("bad_input", "Every asset ID must be a string.")
                continue
            n = self.normalise_id(it)
            if n is None:
                err("not_found", "An entry is not a valid asset ID and is not in the inventory.")
            else:
                cleaned.append(n)

        if not (config.MIN_ASSETS <= supplied <= config.MAX_ASSETS):
            err("wrong_count", f"You must select between {config.MIN_ASSETS} and "
                               f"{config.MAX_ASSETS} assets (got {supplied}).")

        seen, dups = set(), []
        for a in cleaned:
            if a in seen and a not in dups:
                dups.append(a)
            seen.add(a)
        for a in dups:
            err("duplicate", f"{a} was selected more than once.", a)

        for a in dict.fromkeys(cleaned):                    # unique, order preserved
            if a not in self._by_id.index:
                err("not_found", f"{a} does not exist in the inventory.", a)
            elif not bool(self._by_id.loc[a, "eligible"]):
                crit = self._by_id.loc[a, "existing_criticality"]
                err("ineligible", f"{a} is {crit}-criticality; only Low-criticality assets "
                                  f"can be combined.", a)

        if errors:
            return {"valid": False, "asset_ids": [], "assets": [], "errors": errors}

        ids = list(cleaned)
        assets = [self.get_asset(a)[1] for a in ids]
        return {"valid": True, "asset_ids": ids, "assets": assets, "errors": []}
