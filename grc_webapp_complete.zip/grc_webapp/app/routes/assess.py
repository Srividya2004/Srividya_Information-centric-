"""Phases 2-8 routes: assessments, history, reviews, reports, coverage, model status."""
from flask import Blueprint, Response, current_app, jsonify, render_template, request

import config
from app.services import report_service
from app.services.assessment_service import InvalidSelection
from app.services.store import DECISIONS

bp = Blueprint("assess", __name__)


def ext(name):
    return current_app.extensions[name]


def _err(code, msg, status):
    return jsonify({"error": code, "message": msg}), status


# ---------- assessments ----------
@bp.post("/api/assessments")
def create_assessment():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or "asset_ids" not in body:
        return _err("bad_request", 'Send JSON like {"asset_ids": ["AST0001", "AST0002"]}.', 400)
    try:
        res = ext("assessments").run(body["asset_ids"])
    except InvalidSelection as e:
        return jsonify(e.result), 422
    return jsonify({"id": res["id"], "url": f"/assessments/{res['id']}"}), 201


@bp.get("/api/assessments/<int:aid>")
def get_assessment(aid):
    res = ext("store").get_assessment(aid)
    return jsonify(res) if res else _err("not_found", "Assessment not found.", 404)


@bp.get("/api/history")
def history():
    return jsonify(ext("store").history())


@bp.post("/api/assessments/<int:aid>/reviews")
def review(aid):
    res = ext("store").get_assessment(aid)
    if not res:
        return _err("not_found", "Assessment not found.", 404)
    b = request.get_json(silent=True)
    if not isinstance(b, dict):
        return _err("bad_request", "Send JSON with row_no, decision, notes.", 400)
    row_no, decision, notes = b.get("row_no"), b.get("decision"), b.get("notes", "")
    valid_rows = {r["no"] for r in res["compliance"]["report_rows"]}
    if not isinstance(row_no, int) or isinstance(row_no, bool) or row_no not in valid_rows:
        return _err("bad_request", "row_no is not a row of this report.", 422)
    if decision not in DECISIONS:
        return _err("bad_request", "decision must be one of: " + ", ".join(DECISIONS), 422)
    if not isinstance(notes, str) or len(notes) > 2000:
        return _err("bad_request", "notes must be text of at most 2000 characters.", 422)
    ext("store").set_review(aid, row_no, decision, notes.strip())
    return jsonify({"ok": True})


@bp.get("/assessments/<int:aid>/report.pdf")
def pdf(aid):
    res = ext("store").get_assessment(aid)
    if not res:
        return _err("not_found", "Assessment not found.", 404)
    return Response(report_service.pdf_bytes(res), mimetype="application/pdf",
                    headers={"Content-Disposition": f"attachment; filename=assessment_{aid}_report.pdf"})


@bp.get("/assessments/<int:aid>/report.csv")
def csv_report(aid):
    res = ext("store").get_assessment(aid)
    if not res:
        return _err("not_found", "Assessment not found.", 404)
    return Response(report_service.csv_bytes(res), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=assessment_{aid}_recommendations.csv"})


# ---------- coverage ----------
def _k():
    try:
        k = int(request.args.get("k", config.COVERAGE_DEFAULT_K))
    except ValueError:
        return None
    return k if 1 <= k <= config.COVERAGE_MAX_K else None


@bp.get("/api/coverage")
def coverage():
    k = _k()
    if k is None:
        return _err("bad_request", f"k must be an integer from 1 to {config.COVERAGE_MAX_K}.", 400)
    data = ext("compliance").coverage(k)
    rv = ext("store").coverage_reviews()
    for r in data["plan"]:
        r["reviewer_decision"] = rv.get(r["action_id"], {}).get("decision", "Pending")
        r["reviewer_notes"] = rv.get(r["action_id"], {}).get("notes", "")
    return jsonify(data)


@bp.post("/api/coverage/reviews")
def coverage_review():
    b = request.get_json(silent=True)
    if not isinstance(b, dict):
        return _err("bad_request", "Send JSON with action_id, decision, notes.", 400)
    aid, decision, notes = b.get("action_id"), b.get("decision"), b.get("notes", "")
    actions = ext("compliance").coverage_inputs()["actions"]
    if not isinstance(aid, str) or aid not in set(actions["action_id"]):
        return _err("bad_request", "Unknown action_id.", 422)
    if decision not in DECISIONS:
        return _err("bad_request", "decision must be one of: " + ", ".join(DECISIONS), 422)
    if not isinstance(notes, str) or len(notes) > 2000:
        return _err("bad_request", "notes must be text of at most 2000 characters.", 422)
    ext("store").set_coverage_review(aid, decision, notes.strip())
    return jsonify({"ok": True})


@bp.get("/coverage/plan.csv")
def coverage_csv():
    k = _k()
    if k is None:
        return _err("bad_request", f"k must be an integer from 1 to {config.COVERAGE_MAX_K}.", 400)
    return Response(report_service.coverage_csv_bytes(ext("compliance").coverage(k), ext("store").coverage_reviews()),
                    mimetype="text/csv", headers={"Content-Disposition": f"attachment; filename=action_plan_K{k}.csv"})


# ---------- model status ----------
@bp.get("/api/model/status")
def model_status():
    m = ext("model")
    return jsonify({"checks": m.startup_checks, "n_features": len(m.feature_cols),
                    "classes": list(m.le.classes_), "decisions": DECISIONS})


# ---------- pages ----------
@bp.get("/assessments/<int:aid>")
def page_assessment(aid):
    if not ext("store").get_assessment(aid):
        return render_template("notfound.html"), 404
    return render_template("assessment.html", aid=aid, decisions=DECISIONS)


@bp.get("/history")
def page_history():
    return render_template("history.html")


@bp.get("/coverage")
def page_coverage():
    return render_template("coverage.html", decisions=DECISIONS, max_k=config.COVERAGE_MAX_K,
                           default_k=config.COVERAGE_DEFAULT_K)


@bp.get("/model")
def page_model():
    return render_template("model.html", recorded=RECORDED_COMPARISON)


# Values copied from the SAVED OUTPUT of notebook cell 24 (GRC_Pro_clean.ipynb). They are NOT recomputed here.
RECORDED_COMPARISON = [
    ("CatBoost", 0.9776, 0.9766, 0.9743, 0.9722), ("LightGBM", 0.9705, 0.9692, 0.9695, 0.9679),
    ("XGBoost", 0.9657, 0.9642, 0.9681, 0.9665), ("Random Forest", 0.9524, 0.9491, 0.9486, 0.9444),
    ("Naive Bayes", 0.7425, 0.6806, 0.7357, 0.6596)]
