from flask import Blueprint, render_template, current_app

bp = Blueprint("pages", __name__)


@bp.get("/")
def select_assets():
    s = current_app.extensions["inventory"].summary()
    return render_template("select.html", summary=s)
