"""JSON API for Phase 1. All validation happens here/in the service, never in the browser."""
from flask import Blueprint, current_app, jsonify, request
import config

bp = Blueprint("inventory", __name__, url_prefix="/api")


def _svc():
    return current_app.extensions["inventory"]


def _int_arg(name, default):
    raw = request.args.get(name, default)
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


@bp.get("/health")
def health():
    s = _svc().summary()
    return jsonify({"status": "ok", "phase": 1, "total_assets": s["total_assets"],
                    "eligible_low_assets": s["eligible_low_assets"]})


@bp.get("/inventory/summary")
def summary():
    return jsonify(_svc().summary())


@bp.get("/inventory/search")
def search():
    limit = _int_arg("limit", config.SEARCH_DEFAULT_LIMIT)
    offset = _int_arg("offset", 0)
    if limit is None or offset is None:
        return jsonify({"error": "bad_request", "message": "limit and offset must be integers."}), 400
    q = request.args.get("q", "")
    if len(q) > config.SEARCH_MAX_QUERY_LEN:
        return jsonify({"error": "bad_request",
                        "message": f"q is limited to {config.SEARCH_MAX_QUERY_LEN} characters."}), 400
    return jsonify(_svc().search(q=q, asset_type=request.args.get("asset_type") or None,
                                 department=request.args.get("department") or None,
                                 limit=limit, offset=offset))


@bp.get("/inventory/asset/<asset_id>")
def asset(asset_id):
    status, payload = _svc().get_asset(asset_id)
    if status == "not_found":
        return jsonify({"error": "not_found", "message": "Asset not found in the inventory."}), 404
    if status == "ineligible":
        return jsonify({"error": "ineligible",
                        "message": f"{payload['asset_id']} is {payload['existing_criticality']}-criticality; "
                                   f"only Low-criticality assets are eligible."}), 403
    return jsonify(payload)


@bp.post("/selection/validate")
def validate():
    body = request.get_json(silent=True)
    if not isinstance(body, dict) or "asset_ids" not in body:
        return jsonify({"valid": False, "asset_ids": [], "assets": [],
                        "errors": [{"code": "bad_input",
                                    "message": 'Send JSON like {"asset_ids": ["AST0001", "AST0002"]}.'}]}), 400
    result = _svc().validate_selection(body["asset_ids"])
    return jsonify(result), (200 if result["valid"] else 422)
