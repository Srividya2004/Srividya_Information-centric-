# GRC Contextual Risk Assessment - web app (Phases 1-8)

Everything runs in the browser: select assets -> prediction -> SHAP -> LIME -> candidate ISO controls ->
human review -> PDF/CSV report -> history -> Maximum Coverage action plan. No notebook, no `input()`.

## Run (Windows PowerShell, in this folder)
    pip install -r requirements.txt
    python -m pytest tests -q        # expect: 65 passed
    python run.py                    # open http://127.0.0.1:5000  (start-up ~15 s: loads workbook + model, runs checks)

Saved assessments and reviewer decisions live in `instance/grc.db` (created automatically).

## Pages
/ new assessment | /assessments/<id> | /history | /coverage | /model

## What is reused vs new
research/ (your files, byte-identical; fingerprints in research/SOURCES.md):
  data_loader.py, feature_extraction.py, model_utils.py (prepare_inference_row, load_model), compliance_mapper.py
data/: ERG.xlsx and trained_model.pkl (your files)
NOT used: explain.py, report.py, demo.py (the app follows the notebook's executed SHAP/LIME cells instead)
New: app/ (Flask), tests/

## Where each result comes from (notebook = GRC_Pro_clean.ipynb)
prediction   compute_features -> prepare_inference_row -> CatBoost from trained_model.pkl      (cells 26-27)
SHAP         CatBoost native ShapValues, predicted class                                       (cell 29)
LIME         300-row train background, seed 42, 10 features, 3000 samples, fresh explainer     (cell 30-31)
ISO          compliance_mapper.map_to_iso + report rows                                        (cells 43-44)
coverage     compliance_mapper.build_coverage_inputs / greedy_max_coverage                     (cells 46-48)

## Safety checks
- start-up refuses to run if the model's 71 columns / order / classes / test accuracy don't match the workbook
- the server re-validates every selection (2-4 assets, no duplicates, existing_criticality == Low)
- browser code never uses innerHTML; all workbook text is inserted as text

## Choices that are mine (change in config.py)
LIME_R2_WARN_BELOW = 0.5 (warning only; does not change results) | COVERAGE_MAX_K = 50
Model page "recorded comparison" numbers are copied from your notebook output, not recomputed.
