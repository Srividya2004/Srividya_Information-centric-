import sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


@pytest.fixture(scope="session")
def app():
    from app import create_app
    return create_app(db_path=":memory:")   # tests never touch your real history


@pytest.fixture(scope="session")
def client(app):
    return app.test_client()


@pytest.fixture(scope="session")
def raw():
    """Independent read of the workbook (does NOT go through data_loader or the app)."""
    import pandas as pd
    p = ROOT / "data" / "ERG.xlsx"
    assets = pd.read_excel(p, sheet_name="01_Enterprise_Assets")
    risk = pd.read_excel(p, sheet_name="01c_Asset_Risk_Info")
    return assets, risk


@pytest.fixture(scope="session")
def ids(raw):
    _, risk = raw
    low = sorted(risk[risk.existing_criticality == "Low"].asset_id)
    med = sorted(risk[risk.existing_criticality == "Medium"].asset_id)
    high = sorted(risk[risk.existing_criticality == "High"].asset_id)
    return {"low": low, "med": med, "high": high}
