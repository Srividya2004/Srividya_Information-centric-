"""Phases 2-8 tests. Real workbook + real trained_model.pkl. Expected values are the SAVED OUTPUTS
of your notebook GRC_Pro_clean.ipynb (cells 27, 29, 30, 31, 43, 46, 47) - the web app must reproduce them."""
import csv
import hashlib
import io
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
IDS = ["AST0725", "AST0750", "AST0770", "AST0784"]


@pytest.fixture(scope="module")
def made(client):
    r = client.post("/api/assessments", json={"asset_ids": IDS})
    assert r.status_code == 201, r.get_json()
    aid = r.get_json()["id"]
    return aid, client.get(f"/api/assessments/{aid}").get_json()


# ---------- Phase 2: prediction ----------
def test_startup_schema_checks_all_pass(app):
    checks = app.extensions["model"].startup_checks
    assert all(v["ok"] for v in checks.values())
    assert checks["recomputed test accuracy == stored test accuracy"]["detail"].startswith("0.9742857143")
    assert checks["bundle feature_cols == columns rebuilt from workbook"]["detail"] == "71 columns"


def test_prediction_matches_notebook_cell_27(made):
    _, a = made
    p = a["prediction"]
    assert p["label"] == "Medium"
    pr = p["probabilities"]
    assert round(pr["Medium"], 3) == 0.997 and round(pr["High"], 3) == 0.002 and round(pr["Low"], 3) == 0.0
    assert p["model_input_shape"] == [1, 71]
    assert len(a["features"]) == 60
    assert p["dataset_record"]["seen_in_training_set"] is True       # notebook: "Seen in training: True"


def test_features_match_notebook_cell_14(made):
    _, a = made
    f = {x["feature"]: x["value"] for x in a["features"]}
    assert f["combination_size"] == 4 and f["asset_type_diversity"] == 2
    assert f["combined_information_sensitivity"] == "Low" and f["relationship_count"] == 0
    assert f["shared_user_count"] == 0 and f["common_vulnerability_count"] == 2
    assert f["known_exploited_present"] is True and f["control_gap_count"] == 1
    assert f["availability_requirement"] == "Medium"


def test_prediction_matches_the_model_run_directly(app, made):
    """Independent path: call the research modules + model by hand and compare."""
    import numpy as np
    from feature_extraction import compute_features
    from model_utils import prepare_inference_row
    ms, inv = app.extensions["model"], app.extensions["inventory"].inv
    row = prepare_inference_row(compute_features(IDS, inv), ms.bundle)
    direct = ms.model.predict_proba(row)[0]
    got = made[1]["prediction"]["probabilities"]
    for cls, p in zip(ms.le.classes_, direct):
        assert abs(got[cls] - p) < 1e-12


# ---------- Phase 3: SHAP + LIME ----------
def test_shap_matches_notebook_cell_29(made):
    _, a = made
    top = a["shap"]["top"]
    assert len(top) == 10 and top[0]["feature"] == "emergent_capability_score"
    assert round(top[0]["shap"], 4) == 1.4366
    assert [t["feature"] for t in top[1:5]] == ["risk_amplification_score", "attack_feasibility_score",
                                                "combined_control_effectiveness", "threat_severity"]
    ck = a["shap"]["check"]
    assert round(ck["sum_plus_base"], 4) == 4.6222 and abs(ck["sum_plus_base"] - ck["raw_score"]) < 1e-6
    assert len(a["shap"]["table"]) == 71


def test_lime_matches_notebook_cell_30(made):
    _, a = made
    L = a["lime"]
    assert round(L["r2"], 4) == 0.0193 and round(L["local_pred"], 4) == 0.6512
    assert round(L["model_probability"], 4) == 0.9975
    assert L["table"][0]["local condition"] == "emergent_capability_score > 0.17"
    assert round(L["table"][0]["weight"], 4) == 0.1002 and len(L["table"]) == 10


def test_lime_is_reproducible_across_requests(client, made):
    r = client.post("/api/assessments", json={"asset_ids": IDS})
    b = client.get(r.get_json()["url"].replace("/assessments", "/api/assessments")).get_json()
    assert b["lime"]["table"] == made[1]["lime"]["table"] and b["lime"]["r2"] == made[1]["lime"]["r2"]
    assert b["shap"]["table"] == made[1]["shap"]["table"]


def test_comparison_matches_notebook_cell_31(made):
    c = made[1]["comparison"]
    assert {x["feature"] for x in c["both"]} == {"emergent_capability_score", "common_vulnerability_count"}
    assert all(x["agree"] for x in c["both"]) and len(c["only_shap"]) == 8 and len(c["only_lime"]) == 8


def test_low_lime_fit_warning_is_shown(made):
    assert any("LIME's local fit is weak" in w for w in made[1]["warnings"])
    assert any("rule-based" in w for w in made[1]["warnings"])


# ---------- Phase 4: ISO candidates ----------
def test_iso_mapping_matches_notebook_cell_43_44(made):
    C = made[1]["compliance"]
    assert C["summary"].startswith("Prediction: Medium. Considered 14 contributing factor(s): "
                                   "4 mapped to candidate ISO controls, 1 control-gap record(s) listed, 8 not mapped.")
    rows = C["report_rows"]
    assert [r["item"] for r in rows[:4]] == ["common_vulnerability_count", "vulnerability_interaction_score",
                                              "common_weakness_score", "vulnerability_severity"]
    assert all(r["candidate_iso_control"].startswith("A.8.8") for r in rows[:4])
    assert rows[4]["item"] == "AST0725 - Configuration Backup (Planned, effectiveness Low)"
    assert rows[4]["candidate_iso_control"] == "A.8.9" and len(rows) == 5
    assert all(r["status"] == "Candidate - needs human review" for r in rows)


def test_every_iso_id_exists_in_the_reference(app, made):
    import compliance_mapper as cm
    valid = set(cm.get_iso_reference()["iso_control_id"])
    for r in made[1]["compliance"]["recommendations"]:
        assert r["iso_control_id"] in valid


# ---------- Phase 5: Maximum Coverage ----------
def test_coverage_matches_notebook_cells_46_47(client):
    d = client.get("/api/coverage?k=10").get_json()
    u = d["universe"]
    assert (u["flagged_combinations"], u["with_mappable_pair"], u["without"]) == (8295, 6885, 1410)
    assert (u["gap_records"], u["gap_records_unmapped"], u["candidate_actions"], u["pairs"]) == (1172, 413, 759, 12821)
    plan = d["plan"]
    assert [p["new_pairs"] for p in plan[:9]] == [565, 208, 192, 167, 163, 162, 148, 144, 139]
    assert plan[0]["action_id"] == "CTRL01936" and plan[0]["asset_id"] == "AST0648" and plan[0]["pct_of_universe"] == 4.4
    assert d["result"]["pairs_covered"] == 2027 and d["result"]["pct"] == 15.8
    assert all(p["status"] == "Candidate - needs human review" for p in plan)


def test_coverage_is_monotone_and_k_is_validated(client):
    pcts = [client.get(f"/api/coverage?k={k}").get_json()["result"]["pct"] for k in (1, 3, 5, 10, 20, 50)]
    assert pcts == sorted(pcts) and pcts[0] == 4.4
    for bad in ("0", "51", "-1", "abc", ""):
        assert client.get(f"/api/coverage?k={bad}").status_code == 400


# ---------- Backend validation also protects the assessment endpoint ----------
def test_assessment_endpoint_rejects_invalid_selections(client, ids):
    before = len(client.get("/api/history").get_json())
    for bad in (["AST0725"], ["AST0725", "AST0725"], ["AST0725", ids["med"][0]], ["AST0725", ids["high"][0]],
                ["AST0725", "AST9999"], ids["low"][:5], [], "AST0725"):
        r = client.post("/api/assessments", json={"asset_ids": bad})
        assert r.status_code == 422 and not r.get_json()["valid"], bad
    assert client.post("/api/assessments", json={"x": 1}).status_code == 400
    assert client.post("/api/assessments", data="nope", content_type="application/json").status_code == 400
    assert len(client.get("/api/history").get_json()) == before          # nothing saved for rejected requests


# ---------- Phase 6: reports ----------
def test_pdf_and_csv_reports(client, made):
    aid, _ = made
    pdf = client.get(f"/assessments/{aid}/report.pdf")
    assert pdf.status_code == 200 and pdf.data[:5] == b"%PDF-" and len(pdf.data) > 5000
    assert "pdf" in pdf.headers["Content-Type"]
    csvr = client.get(f"/assessments/{aid}/report.csv")
    rows = list(csv.reader(io.StringIO(csvr.data.decode("utf-8-sig"))))
    assert rows[0][0] == "no" and len(rows) == 6 and rows[1][3].startswith("A.8.8")
    assert client.get("/assessments/99999/report.pdf").status_code == 404
    assert client.get("/assessments/99999/report.csv").status_code == 404


def test_pdf_text_contains_the_key_results(client, made):
    import subprocess, tempfile
    aid, _ = made
    data = client.get(f"/assessments/{aid}/report.pdf").data
    with tempfile.NamedTemporaryFile(suffix=".pdf") as f:
        f.write(data); f.flush()
        try:
            txt = subprocess.run(["pdftotext", "-layout", f.name, "-"], capture_output=True, text=True).stdout
        except FileNotFoundError:
            pytest.skip("pdftotext not installed")
    for needle in ("AST0725", "Medium", "emergent_capability_score", "A.8.8", "CANDIDATE", "0.0193"):
        assert needle in txt, needle


# ---------- Phase 7: history + reviews ----------
def test_history_lists_assessment(client, made):
    h = client.get("/api/history").get_json()
    assert any(x["id"] == made[0] and x["asset_ids"] == IDS and x["predicted_label"] == "Medium" for x in h)


def test_review_decisions_are_saved_and_flow_into_reports(client, made):
    aid, _ = made
    r = client.post(f"/api/assessments/{aid}/reviews", json={"row_no": 1, "decision": "Accepted", "notes": "Patch records checked"})
    assert r.status_code == 200
    got = client.get(f"/api/assessments/{aid}").get_json()["compliance"]["report_rows"]
    assert got[0]["reviewer_decision"] == "Accepted" and got[0]["reviewer_notes"] == "Patch records checked"
    assert got[1]["reviewer_decision"] == "Pending"
    csvtxt = client.get(f"/assessments/{aid}/report.csv").data.decode("utf-8-sig")
    assert "Accepted" in csvtxt and "Patch records checked" in csvtxt


def test_review_input_is_validated(client, made):
    aid, _ = made
    u = f"/api/assessments/{aid}/reviews"
    for body in ({"row_no": 99, "decision": "Accepted"}, {"row_no": 1, "decision": "Maybe"}, {"row_no": "1", "decision": "Accepted"},
                 {"row_no": True, "decision": "Accepted"}, {"row_no": 1, "decision": "Accepted", "notes": "x" * 2001},
                 {"row_no": 1, "decision": "Accepted", "notes": 5}):
        assert client.post(u, json=body).status_code == 422, body
    assert client.post("/api/assessments/99999/reviews", json={"row_no": 1, "decision": "Accepted"}).status_code == 404
    assert client.post(u, data="x", content_type="application/json").status_code == 400


def test_coverage_review_roundtrip(client):
    assert client.post("/api/coverage/reviews", json={"action_id": "CTRL01936", "decision": "Needs more evidence", "notes": "ask IT"}).status_code == 200
    plan = client.get("/api/coverage?k=3").get_json()["plan"]
    assert plan[0]["reviewer_decision"] == "Needs more evidence" and plan[1]["reviewer_decision"] == "Pending"
    assert client.post("/api/coverage/reviews", json={"action_id": "NOPE", "decision": "Accepted"}).status_code == 422
    assert b"Needs more evidence" in client.get("/coverage/plan.csv?k=3").data


# ---------- Pages ----------
@pytest.mark.parametrize("path", ["/", "/history", "/coverage", "/model"])
def test_pages_render(client, path):
    assert client.get(path).status_code == 200


def test_assessment_page_and_missing_page(client, made):
    assert client.get(f"/assessments/{made[0]}").status_code == 200
    assert client.get("/assessments/99999").status_code == 404


# ---------- Integrity / safety ----------
def test_research_files_still_unchanged():
    found = re.findall(r"\| (\S+\.(?:py|xlsx)) \| ([0-9a-f]{32}) \|", (ROOT / "research" / "SOURCES.md").read_text())
    for n, md5 in found:
        p = ROOT / ("data" if n.endswith("xlsx") else "research") / Path(n).name
        assert hashlib.md5(p.read_bytes()).hexdigest() == md5, n
    assert hashlib.md5((ROOT / "data" / "trained_model.pkl").read_bytes()).hexdigest() == "2921c3648cba90ac8688860138252fe8"


def test_unused_research_files_are_not_used_by_the_app():
    for f in (ROOT / "app").rglob("*.py"):
        t = f.read_text()
        assert not re.search(r"^\s*(import|from)\s+(explain|report|demo)\b", t, re.M), f


def test_frontend_never_uses_innerhtml():
    for f in (ROOT / "app" / "static" / "js").glob("*.js"):
        assert "innerHTML" not in f.read_text(), f


def test_schema_mismatch_stops_the_app(tmp_path):
    import joblib
    from app import create_app
    from app.services.model_service import SchemaMismatch
    b = joblib.load(ROOT / "data" / "trained_model.pkl")
    b["feature_cols"] = list(reversed(b["feature_cols"]))               # same columns, wrong order
    p = tmp_path / "bad.pkl"; joblib.dump(b, p)
    with pytest.raises(SchemaMismatch):
        create_app(model_path=p, db_path=":memory:")
