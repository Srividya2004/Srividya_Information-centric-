"""Phase 1 tests: run against the REAL ERG.xlsx. No mocks."""
import hashlib
import random
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent

NOTEBOOK_SELECTION = ["AST0725", "AST0750", "AST0770", "AST0784"]


def post(client, ids):
    r = client.post("/api/selection/validate", json={"asset_ids": ids})
    return r.status_code, r.get_json()


# ---------------- reuse integrity ----------------
def test_reused_files_are_byte_identical_to_originals():
    found = re.findall(r"\| (\S+\.(?:py|xlsx)) \| ([0-9a-f]{32}) \|",
                       (ROOT / "research" / "SOURCES.md").read_text())
    expected = {Path(n).name: md5 for n, md5 in found}
    assert set(expected) == {"data_loader.py", "feature_extraction.py", "model_utils.py",
                             "compliance_mapper.py", "ERG.xlsx"}
    for name, md5 in expected.items():
        path = ROOT / ("data" if name.endswith("xlsx") else "research") / name
        assert hashlib.md5(path.read_bytes()).hexdigest() == md5, name


def test_app_uses_the_research_data_loader(app):
    import data_loader
    assert Path(data_loader.__file__).resolve() == ROOT / "research" / "data_loader.py"
    assert type(app.extensions["inventory"].inv) is data_loader.EnterpriseInventory


# ---------------- inventory facts ----------------
def test_inventory_counts_match_workbook(client, raw):
    assets, risk = raw
    s = client.get("/api/inventory/summary").get_json()
    assert s["total_assets"] == len(assets) == 1082
    assert s["eligible_low_assets"] == 649
    assert s["by_criticality"] == {"Low": 649, "Medium": 292, "High": 141}


def test_eligible_set_equals_independent_pandas_filter(app, raw):
    _, risk = raw
    expected = set(risk[risk.existing_criticality == "Low"].asset_id)
    svc = app.extensions["inventory"]
    got = set(svc.catalogue[svc.catalogue.eligible].asset_id)
    assert got == expected and len(got) == 649


# ---------------- search ----------------
def _all_search_results(client, **params):
    out, offset = [], 0
    while True:
        d = client.get("/api/inventory/search", query_string={**params, "limit": 100, "offset": offset}).get_json()
        out += d["results"]
        offset += 100
        if offset >= d["total"]:
            return out, d["total"]


def test_search_returns_only_low_assets_everywhere(client, ids):
    rows, total = _all_search_results(client)
    assert total == len(rows) == 649
    assert {r["asset_id"] for r in rows} == set(ids["low"])
    assert {r["existing_criticality"] for r in rows} == {"Low"}
    assert not ({r["asset_id"] for r in rows} & (set(ids["med"]) | set(ids["high"])))


@pytest.mark.parametrize("q", ["laptop", "AST0725", "ast07", "printer", "network device", "zzzz-no-match", "%", "'; DROP TABLE x;--", "<script>"])
def test_search_never_leaks_non_low(client, q):
    rows, _ = _all_search_results(client, q=q)
    assert all(r["existing_criticality"] == "Low" for r in rows)


def test_search_finds_known_assets(client):
    d = client.get("/api/inventory/search", query_string={"q": "AST0725"}).get_json()
    assert [r["asset_id"] for r in d["results"]] == ["AST0725"]
    assert d["results"][0]["asset_name"] == "WirelessAccessPoint-039"
    d = client.get("/api/inventory/search", query_string={"q": "networkedprinter-004"}).get_json()
    assert [r["asset_id"] for r in d["results"]] == ["AST0750"]


def test_search_filters_and_paging(client, raw):
    assets, risk = raw
    low = set(risk[risk.existing_criticality == "Low"].asset_id)
    n_ws = int(assets[assets.asset_id.isin(low) & (assets.asset_type == "Workstation")].shape[0])
    d = client.get("/api/inventory/search", query_string={"asset_type": "Workstation", "limit": 5}).get_json()
    assert d["total"] == n_ws and len(d["results"]) == 5
    d2 = client.get("/api/inventory/search", query_string={"asset_type": "Workstation", "limit": 5, "offset": 5}).get_json()
    assert not ({r["asset_id"] for r in d["results"]} & {r["asset_id"] for r in d2["results"]})


def test_search_does_not_return_medium_or_high_even_when_named(client, ids):
    med = ids["med"][0]
    d = client.get("/api/inventory/search", query_string={"q": med}).get_json()
    assert d["total"] == 0


def test_search_rejects_bad_parameters(client):
    assert client.get("/api/inventory/search?limit=abc").status_code == 400
    assert client.get("/api/inventory/search?q=" + "a" * 101).status_code == 400
    d = client.get("/api/inventory/search?limit=100000&offset=-5").get_json()   # clamped, not an error
    assert d["limit"] == 100 and d["offset"] == 0


# ---------------- single asset ----------------
def test_asset_endpoint(client, ids):
    assert client.get("/api/inventory/asset/AST0725").status_code == 200
    assert client.get("/api/inventory/asset/ast0725").status_code == 200
    r = client.get(f"/api/inventory/asset/{ids['high'][0]}")
    assert r.status_code == 403 and r.get_json()["error"] == "ineligible"
    assert client.get("/api/inventory/asset/AST9999").status_code == 404
    assert client.get("/api/inventory/asset/..%2f..%2fetc").status_code == 404


# ---------------- selection validation: valid ----------------
def test_notebook_selection_is_valid(client):
    code, d = post(client, NOTEBOOK_SELECTION)
    assert code == 200 and d["valid"] and d["asset_ids"] == NOTEBOOK_SELECTION
    assert [a["asset_name"] for a in d["assets"]] == ["WirelessAccessPoint-039", "NetworkedPrinter-004",
                                                      "NetworkedPrinter-024", "NetworkedPrinter-038"]


@pytest.mark.parametrize("n", [2, 3, 4])
def test_valid_sizes(client, ids, n):
    code, d = post(client, ids["low"][:n])
    assert code == 200 and d["valid"] and len(d["assets"]) == n


def test_normalises_case_and_whitespace_and_comma_string(client):
    code, d = post(client, "  ast0725 , AST0750 ,")
    assert code == 200 and d["asset_ids"] == ["AST0725", "AST0750"]


# ---------------- selection validation: invalid ----------------
def codes(d):
    return {e["code"] for e in d["errors"]}


def test_reject_too_few(client, ids):
    for sel in ([], [ids["low"][0]], ""):
        code, d = post(client, sel)
        assert code == 422 and not d["valid"] and "wrong_count" in codes(d)


def test_reject_too_many(client, ids):
    code, d = post(client, ids["low"][:5])
    assert code == 422 and "wrong_count" in codes(d)
    code, d = post(client, ids["low"][:200])
    assert code == 422 and "too_many" in codes(d)


def test_reject_duplicates_including_case_variants(client):
    code, d = post(client, ["AST0725", "AST0750", "AST0725"])
    assert code == 422 and "duplicate" in codes(d)
    code, d = post(client, ["AST0725", "ast0725"])
    assert code == 422 and "duplicate" in codes(d)


def test_reject_nonexistent(client):
    code, d = post(client, ["AST0725", "AST9999"])
    assert code == 422 and "not_found" in codes(d)
    assert any(e.get("asset_id") == "AST9999" for e in d["errors"])


def test_reject_medium_and_high_with_reason(client, ids):
    for level, key in (("Medium", "med"), ("High", "high")):
        bad = ids[key][0]
        code, d = post(client, ["AST0725", bad])
        assert code == 422 and "ineligible" in codes(d)
        msg = next(e["message"] for e in d["errors"] if e["code"] == "ineligible")
        assert bad in msg and level in msg


def test_all_medium_high_assets_rejected(client, ids):
    for aid in ids["med"] + ids["high"]:
        code, d = post(client, ["AST0725", aid])
        assert code == 422 and "ineligible" in codes(d), aid


def test_reject_malformed_input(client):
    for bad in (["AST0725", None], ["AST0725", 5], ["AST0725", ["AST0750"]], ["<script>alert(1)</script>", "AST0725"],
                ["AST0725", "' OR 1=1 --"], ["AST0725", "A" * 500]):
        code, d = post(client, bad)
        assert code in (200, 422) and not d["valid"], bad
    for payload in ({"asset_ids": 123}, {"asset_ids": {"a": 1}}, {"asset_ids": None}):
        r = client.post("/api/selection/validate", json=payload)
        assert r.status_code == 422 and not r.get_json()["valid"]


def test_reject_bad_requests(client):
    assert client.post("/api/selection/validate", data="not json", content_type="application/json").status_code == 400
    assert client.post("/api/selection/validate", json={"other": 1}).status_code == 400
    assert client.post("/api/selection/validate", json=[1, 2]).status_code == 400
    assert client.post("/api/selection/validate", data="AST0725,AST0750").status_code == 400
    assert client.get("/api/selection/validate").status_code == 405


def test_error_messages_do_not_echo_raw_script_input(client):
    _, d = post(client, ["<script>alert(1)</script>", "AST0725"])
    assert "<script>" not in str(d)


# ---------------- parity with the notebook rule ----------------
def notebook_rule(selected, low_ids):
    """Verbatim logic of the notebook's selection cell, returned as a validity flag."""
    selected = [a.strip().upper() for a in selected if a.strip()]
    problems = []
    if len(selected) < 2 or len(selected) > 4:
        problems.append("count")
    if len(set(selected)) != len(selected):
        problems.append("dup")
    for a in selected:
        if a not in low_ids:
            problems.append("pool")
    return not problems


def test_backend_agrees_with_notebook_rule_on_random_selections(client, ids, app):
    rnd = random.Random(7)
    low = set(ids["low"])
    pool = ids["low"] + ids["med"] + ids["high"] + ["AST9999", "ast0001", " AST0002 ", ""]
    disagreements = []
    for _ in range(400):
        sel = [rnd.choice(pool) for _ in range(rnd.randint(0, 6))]
        _, d = post(client, sel)
        if d["valid"] != notebook_rule(sel, low):
            disagreements.append(sel)
    assert not disagreements, disagreements[:3]


# ---------------- compatibility with the reused feature code ----------------
def test_validated_selection_is_accepted_by_compute_features(client, app):
    """The reused compute_features must run on a selection the backend accepted
    (checks data compatibility only; no model, no results interpreted)."""
    from feature_extraction import compute_features
    _, d = post(client, NOTEBOOK_SELECTION)
    feats = compute_features(d["asset_ids"], app.extensions["inventory"].inv)
    assert isinstance(feats, dict) and len(feats) in (60, 61)


# ---------------- pages ----------------
def test_page_renders_and_health(client):
    r = client.get("/")
    assert r.status_code == 200 and b"Select assets to combine" in r.data and b"649" in r.data
    assert client.get("/api/health").get_json()["status"] == "ok"
    assert client.get("/static/js/select.js").status_code == 200
