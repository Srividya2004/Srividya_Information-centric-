# research/ - your original files, copied UNCHANGED

The web app imports these; it never edits them. `tests/test_phase1.py` re-checks the fingerprints below.

| File | MD5 | Copied from |
|---|---|---|
| data_loader.py | 41b328d1fa6b04407c69af29645a7dd9 | your upload (9daf2cad) |
| feature_extraction.py | 4b671601637ad0cb4872b925fd7497c6 | your upload (e211f1d5) |
| model_utils.py | d987af5443f3270fb290437fdffe7c4c | your upload (dde53f5e) |
| compliance_mapper.py | a501ea930f56c9d9b78184e26979f109 | your upload (e19015c3, original CRLF line endings kept) |
| ../data/ERG.xlsx | 898dc93168bfd9d3ba0b45cf9d7ff59d | your upload ERG.xlsx |

Phase 1 uses only data_loader.py. The other three are copied now so later phases reuse them as they are.
